<?php
    include "../model/Utilisateur.php";
    include "../controller/UtilisateurC.php";

   

    // create user
   

    // create an instance of the controller
    $utilisateurc = new UtilisateurC();
    if ( isset($_POST["username"]) && isset($_POST["first_name"]) && isset($_POST["last_name"]) && isset($_POST["email"]) && isset($_POST["day_of_birth"]) &&  isset($_POST["phone_number"]) &&  isset($_POST["country"]) &&  isset($_POST["picture"]) &&   isset($_POST["password"]) ) {
        if (!empty($_POST["first_name"]) && !empty($_POST["last_name"]) &&  !empty($_POST["email"]) &&  !empty($_POST["day_of_birth"]) && !empty($_POST["phone_number"]) && !empty($_POST["country"]) && !empty($_POST["username"]) && !empty($_POST["password"])
        ) {
            $user = new Utilisateur($_POST["username"],$_POST['first_name'],$_POST['last_name'], $_POST['email'],$_POST['day_of_birth'],$_POST["phone_number"],$_POST["country"], $_POST["picture"],$_POST['password']);
            $utilisateurc->ajouterUtilisateur($user);
            header('Location:afficherUtilisateurs.php');
        }
        else
            $error = "Missing information";
    }

    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="wusernameth=device-wusernameth, initial-scale=1.0">
    <title>Connexion</title>
</head>
    <body>
        <button><a href="afficherUtilisateurs.php">Retour à la liste</a></button>
        <hr>
        
       
        <form action="" method="POST">
            <table border="1" align="center">

                <tr>
                    <td rowspan='5' colspan='1'>Fiche Personnelle</td>
                    <td>
                        <label for="first_name">first_name:
                        </label>
                    </td>
                    <td><input type="text" name="first_name"  maxlength="20"></td>
                </tr>
                <tr>
                    <td>
                        <label for="last_name">last_name:
                        </label>
                    </td>
                    <td><input type="text" name="last_name"  maxlength="20"></td>
                </tr>
                <tr>
                 
                <tr>
                    <td>
                        <label for="phone_number">phone number:
                        </label>
                    </td>
                    <td><input type="phone" name="phone_number"  maxlength="20"></td>
                </tr>
                
                <tr>
                    <td>
                        <label for="email">Adresse mail:
                        </label>
                    </td>
                    <td>
                        <input type="email" name="email"  >
                    </td>
                </tr>
                <tr>
                    <td rowspan='3' colspan='1'>Information de Connexion</td>
                    <td>
                        <label for="day_of_birth">day_of_birth:
                        </label>
                    </td>
                    <td>
                        <input type="text" name="day_of_birth"  >
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="username">username:
                        </label>
                    </td>
                    <td><input type="text" name="username"  maxlength="20"></td>
                </tr>
                <tr>
                    <td>
                        <label for="password">Mot de passe:
                        </label>
                    </td>
                    <td>
                        <input type="password" name="password" >
                    </td>
                </tr>
                
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Envoyer"> 
                    </td>
                    <td>
                        <input type="reset" value="Annuler" >
                    </td>
                </tr>
            </table>
        </form>
    </body>
</html>