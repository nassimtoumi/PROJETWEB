<?PHP
	include "../controller/UtilisateurC.php";
	include_once '../model/Utilisateur.php';

	$utilisateurC=new UtilisateurC();
	
	if (isset($_POST["username"])){
		$utilisateurC->supprimerUtilisateur($_POST["username"]);
		header('Location:afficherUtilisateurs.php');
	}

?>