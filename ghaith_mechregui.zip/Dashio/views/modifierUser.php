<?php
    include "../controller/UtilisateurC.php";
    include_once '../model/Utilisateur.php';

	$utilisateurC = new UtilisateurC();
	$error = "";

	if (
        isset($_POST["first_name"]) && 
        isset($_POST["last_name"]) &&
        isset($_POST["email"]) && 
        isset($_POST["day_of_birth"]) && 
        isset($_POST["phone_number"]) &&
        isset($_POST["country"]) &&
        isset($_POST["picture"]) &&
        isset($_POST["password"])
    ){
		if (
            !empty($_POST["first_name"]) && 
            !empty($_POST["last_name"]) && 
            !empty($_POST["email"]) && 
            !empty($_POST["day_of_birth"]) &&
            !empty($_POST["phone_number"]) && 
            !empty($_POST["picture"]) && 
            !empty($_POST["country"]) &&  
            !empty($_POST["password"])
        ) {
            $user = new Utilisateur(
                $_POST['first_name'],
                $_POST['last_name'], 
                $_POST['email'],
                $_POST['day_of_birth'],
                $_POST["phone_number"],
                $_POST["picture"],
                $_POST["country"],
                $_POST['password']
            );
            
            $utilisateurC->modifierUtilisateur($user, $_GET['username']);
            //header('Location:afficherUtilisateurs.php');
        }
        else
            $error = "Missing information";
	}

?>
<html>
	<head>
		<title>Modifier Utilisateur</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="wusernameth=device-wusernameth, initial-scale=1.0">
	</head>
	<body>
		<button><a href="afficherUtilisateurs.php">Retour à la liste</a></button>
        <hr>
        
        <div username="error">
            <?php echo $error; ?>
        </div>
		
		<?php
			if (isset($_GET['username'])){
				$user = $utilisateurC->recupererUtilisateur1($_GET['username']);
				
		?>
		<form action="" method="POST">
            <table align="center">
                <tr>
                    <td rowspan='3' colspan='1'>Fiche Personnelle</td>
                    <td>
                        <label for="first_name">first_name:
                        </label>
                    </td>
                    <td><input type="text" name="first_name" username="first_name" maxlength="20" value = "<?php echo $user->first_name; ?>"></td>
                </tr>
                <tr>
                    <td>
                        <label for="last_name">last_name:
                        </label>
                    </td>
                    <td><input type="text" name="last_name" username="last_name" maxlength="20" value = "<?php echo $user->last_name; ?>"></td>
                </tr>
                
                <tr>
                    <td>
                        <label for="email">Adresse mail:
                        </label>
                    </td>
                    <td>
                        <input type="email" name="email" username="email" pattern=".+@gmail.com|.+@esprit.tn" value = "<?php echo $user->Email; ?>">
                    </td>
                </tr>
                <tr>
                    <td rowspan='2' colspan='1'>Information de Connexion</td>
                    <td>
                        <label for="day_of_birth">day_of_birth:
                        </label>
                    </td>
                    <td>
                        <input type="text" name="day_of_birth" username="day_of_birth" value = "<?php echo $user->day_of_birth; ?>">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="password">Mot de passe:
                        </label>
                    </td>
                    <td>
                        <input type="password" name="password"  value = "<?php echo $user->Password; ?>">
                    </td>
                </tr>
                
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Modifier" name = "modifer"> 
                    </td>
                    <td>
                        <input type="reset" value="Annuler" >
                    </td>
                </tr>
            </table>
        </form>
		<?php
		}
		?>
	</body>
</html>