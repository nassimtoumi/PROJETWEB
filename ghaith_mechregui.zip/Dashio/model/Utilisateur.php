<?PHP
	class Utilisateur{
		private $id_user ;
		private  $username ;
		private  $first_name ;
		private  $last_name;
		private $email;
		private  $day_of_birth ;
		private $phone_number;
		private  $password;
		private  $country;
		private $picture;

		
	public	function __construct($username,$first_name,$last_name,$email,$day_of_birth,$phone_number,$country,$picture,$password){
			$this->username=$username;
			$this->first_name=$first_name;
			$this->last_name=$last_name;
			$this->email=$email;
			$this->day_of_birth= $day_of_birth;
			$this->phone_number=$phone_number;
			$this->country=$country;
			$this->picture=$picture;
			$this->password=$password;
		}
		
		function getId(){
			return $this->id_user;
		}
		function getUsername(){
			return $this->username;
		}
		function getFirst_name(){
			return $this->first_name;
		}
		function getLast_name(){
			return $this->last_name;
		}
		
		function getEmail(){
			return $this->email;
		}
		function getDay_of_birth(){
			return $this->day_of_birth;
		}
		function getPhone_number(){
			return $this->phone_number;
		}
		function getCountry(){
			return $this->country;
		}
		function getPicture(){
			return $this->picture;
		}
		
		function getPassword(){
			return $this->password;
		}
		function setId( $id_user){
			$this->id_user=$id_user;
		}

		function setFirst_name( $first_name){
			$this->first_name=$first_name;
		}
		function setLast_name( $last_name){
			$this->last_name;
		}
		function setEmail( $email){
			$this->email=$email;
		}
		
	
		function setDay_of_birth( $day_of_birth) {
			$this->day_of_birth=$day_of_birth;
		}
		function setCountry($country){
			$this->country=$country;
		}
		function setPicture( $picture){
			$this->picture=$picture;
		}
		function setPhone_number($phone_number){
			$this->phone_number=$phone_number;
		}
		function setPassword($password){
			$this->password=$password;
		}
	}
?>