<?PHP
	include "../config.php";


	class UtilisateurC {
		
		 public function ajouterUtilisateur($Utilisateur){
			$sql="insert into Utilisateur (username,first_name, last_name, email,day_of_birth, phone_number,country,picture, password) 
			values (:username,:first_name,:last_name,:email,:day_of_birth,:phone_number,:country,:picture,:password)";
			$db = config::getConnexion();
			try{
				$req=$db->prepare($sql);
			
			
					$username = $Utilisateur->getUsername();
					$first_name = $Utilisateur->getFirst_name();
					$last_name =$Utilisateur->getLast_name();
					$email = $Utilisateur->getEmail();
					$day_of_birth = $Utilisateur->getDay_of_birth();
				   $phone_number = $Utilisateur->getPhone_number();
				    $country =$Utilisateur->getCountry();
					$picture = $Utilisateur->getPicture();
					$password = $Utilisateur->getPassword();
					$req->bindValue(':username',$username);
					$req->bindValue(':first_name',$first_name);
					$req->bindValue(':last_name',$last_name);
					$req->bindValue(':email',$email);
					$req->bindValue(':day_of_birth',$day_of_birth);
					$req->bindValue(':phone_number',$phone_number);
					$req->bindValue(':country',$country);
					$req->bindValue(':picture',$picture);
					$req->bindValue(':password',$password);
					$req->execute();		
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}			
		}
		
		 public function afficherUtilisateurs(){
			
			$sql="SELECT * FROM Utilisateur";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}	
		}

		public function supprimerUtilisateur($username){
			$sql="DELETE FROM Utilisateur WHERE username= :username";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':username',$username);
			try{
				$req->execute();
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
	public function modifierUtilisateur($Utilisateur){
			$sql="UPDATE utilisateur SET username= :username,first_name=first_name:, last_name= :last_name , email= :email, day_of_birth= :day_of_birth ,phone_number= :phone_number,country= :country where id_user=:id_user";
			$db = config::getConnexion();
			try{
				$req=$db->prepare($sql);
				$username=$Utilisateur->username;
			    $first_name=$Utilisateur->first_name;
				$last_name=$Utilisateur->lastt_name;
				$email=$Utilisateur->email;
				$day_of_birth=$Utilisateur->day_of_birth;
				$phone_number=$Utilisateur->phone_number;
				$country=$Utilisateur->country;
				$id_user=$Utilisateur->id_user;

			$req->bindValue(':id_user',$id_user);
			$req->bindValue(':first_name',$first_name);
			$req->bindValue(':last_name',$last_name);
			$req->bindValue(':email',$email);
			$req->bindValue(':day_of_birth',$day_of_birth);
			$req->bindValue(':phone_number',$phone_number);
			$req->bindValue(':country',$country);
			$req->execute();
			}
			catch(Exception $e){
				die('Erreur:' .$e->getMessage());
			}		
		}
		

		 public function recupererUtilisateur1($username){
			$sql="SELECT * from Utilisateur where username=$username";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();
				
				$user = $query->fetch(PDO::FETCH_OBJ);
				return $user;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		
	}

?>